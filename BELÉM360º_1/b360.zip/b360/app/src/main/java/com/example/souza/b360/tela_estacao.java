package com.example.souza.b360;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ActionProvider;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.youtube.player.internal.v;

public class tela_estacao extends AppCompatActivity {
private WebView webvideo;
private  WebView webmap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_estacao);
        webvideo = (WebView) findViewById(R.id.videoestacao);
        WebSettings wsvideo = webvideo.getSettings();
        wsvideo.setJavaScriptEnabled(true);
       wsvideo.setSupportZoom(false);
       String html = "<html>";
        html+="        <body>";
        html+="   <iframe width=\"100%\" height=\"225dp\" src=\"https://www.youtube.com/embed/hwG8OD3e1vY\" frameborder=\"0\" allow=\"autoplay; encrypted-media\" allowfullscreen></iframe>    ";

       html+= "     <div id=\"fb-root\"></div>        ";
        html+="<script>(function(d, s, id) {";
            html+="var js, fjs = d.getElementsByTagName(s)[0];";
        html+="if (d.getElementById(id)) return;";
        html+="js = d.createElement(s); js.id = id;";
        html+="     js.src = 'https://connect.facebook.net/pt_BR/sdk.js#xfbml=1&version=v3.0';         ";
        html+="      fjs.parentNode.insertBefore(js, fjs);   ";
        html+="}(document, 'script', 'facebook-jssdk'));</script>";
        html+="    <div class=\"fb-comments\" data-href=\"https://localhost:80\" data-width=\"200\" data-numposts=\"5\"></div>      ";
        html+="</body>";
        html+=" </html>";
        webvideo.loadData(html, "text/html", "UTF-8") ;



        webmap = (WebView) findViewById(R.id.webmapaestacao);
        WebSettings wsmap = webmap.getSettings();
        wsmap.setJavaScriptEnabled(true);
        wsmap.setSupportZoom(false);
        String html2 = "<html>";
        html2+="        <body>";
        html2+=" <iframe src=\"https://www.google.com/maps/embed?pb=!1m19!1m8!1m3!1d7977.077662560398!2d-48.50168031284266!3d-1.451078695410711!3m2!1i1024!2i768!4f13.1!4m8!3e0!4m0!4m5!1s0x92a48ebec7cc3cc7%3A0x9ff7f9d83af49156!2sEsta%C3%A7%C3%A3o+das+Docas%2C+Av.+Boulevard+Castilho%2C+s%2Fn+-+Campina%2C+Bel%C3%A9m+-+PA%2C+66053-150!3m2!1d-1.4498567!2d-48.5012488!5e0!3m2!1spt-BR!2sbr!4v1529268056524\" width=\"350\" height=\"250\" frameborder=\"0\" style=\"border:0\" allowfullscreen></iframe>    ";

        html2+="</body>";
        html2+=" </html>";
        webmap.loadData(html2, "text/html", "UTF-8") ;
    }
    public void compartilhar(View v){
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT, "Olha esse app que encontrei!!!");
        i.putExtra(Intent.EXTRA_TEXT, "#####link#####");
        startActivity(Intent.createChooser(i, "compartilhar"));
    }



    }

